module.exports = {
  plugins: {
    'postcss-rtl': {},
  },
}
